package com.ceshiren.page;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class By {
    private String key;
    private String appium;
    private String oss;
}
