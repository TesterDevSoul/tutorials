# 元素定位表达式
| 关键字驱动框架定位 | appium定位 |
|-----------|----------|
| xpath | xpath |
| css | cssSelector |
| androidUIAutomator | androidUIAutomator |
| class | className |
